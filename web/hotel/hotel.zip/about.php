<?php 
$page = 'about.php';
include 'includes/header.inc.php';

 ?>
    		<div id="main-content">
    			<p>
    				<img src="http://everydaylife.globalpost.com/DM-Resize/photos.demandstudios.com/getty/article/151/226/86543839.jpg?w=600&h=600&keep_ratio=1&webp=1" alt="" width="300" height="200"><img src="http://www.hotelesdunas.com/content/imgsxml/es/galerias/texto/356/piscina-noche-hotel-dunas-mirador-maspalomas.jpg" alt="" width="300" height="200"><img src="http://www.villazzo.com/about-luxury-villa-rentals/media/image/services/VillaHotel-Staff-01.jpg" alt="" width="300" height="200"> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quo, pariatur, deleniti ducimus animi excepturi asperiores odit laboriosam eaque accusantium totam facere dolorem ab nesciunt vel eos distinctio itaque corporis. Voluptates.
    			</p>
                <p>
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quo, pariatur, deleniti ducimus animi excepturi asperiores odit laboriosam eaque accusantium totam facere dolorem ab nesciunt vel eos distinctio itaque corporis. Voluptates.Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quo, pariatur, deleniti ducimus animi excepturi asperiores odit laboriosam eaque accusantium totam facere dolorem ab nesciunt vel eos distinctio itaque corporis. Voluptates.
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quo, pariatur, deleniti ducimus animi excepturi asperiores odit laboriosam eaque accusantium totam facere dolorem ab nesciunt vel eos distinctio itaque corporis. Voluptates.
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quo, pariatur, deleniti ducimus animi excepturi asperiores odit laboriosam eaque accusantium totam facere dolorem ab nesciunt vel eos distinctio itaque corporis. Voluptates.
                </p>
    		</div>
<?php 

include 'includes/footer.inc.php';

 ?>