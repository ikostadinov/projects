 <?php 
$page='';
include 'includes/header.inc.php';

 ?>
            <div id="main-content">
            <div id="gal">
            <h4><a href="gallery.php">Gallery</a>&nbsp;>>&nbsp;Restaurant</h4>
            <div class="image-row">
                    <div class="image-set">
                    <a class="example-image-link" href="http://www.limousine-hire-perth.com.au/C_RESTAURANT.jpg" data-lightbox="example-set" data-title="Click the right half of the image to move forward."><img class="example-image" src="http://www.limousine-hire-perth.com.au/C_RESTAURANT.jpg" alt=""/></a>
                    <a class="example-image-link" href="http://www.limousine-hire-perth.com.au/C_RESTAURANT.jpg" data-lightbox="example-set" data-title="Or press the right arrow on your keyboard."><img class="example-image" src="http://www.limousine-hire-perth.com.au/C_RESTAURANT.jpg" alt="" /></a>
                    <a class="example-image-link" href="http://www.limousine-hire-perth.com.au/C_RESTAURANT.jpg" data-lightbox="example-set" data-title="The next image in the set is preloaded as you're viewing."><img class="example-image" src="http://www.limousine-hire-perth.com.au/C_RESTAURANT.jpg" alt="" /></a>
                    <a class="example-image-link" href="http://www.limousine-hire-perth.com.au/C_RESTAURANT.jpg" data-lightbox="example-set" data-title="Click anywhere outside the image or the X to the right to close."><img class="example-image" src="http://www.limousine-hire-perth.com.au/C_RESTAURANT.jpg" alt="" /></a>
            </div>
            <script src="js/lightbox.js"></script>
            </div>
<?php 

include 'includes/footer.inc.php';

 ?>