<?php 
$page='gallery.php';
include 'includes/header.inc.php';

 ?>
    		<div id="main-content">
            <a class="image"  href="#">
                <span class="roll" >Rooms</span>
                <img class="imgborder" alt="" src="http://upload.wikimedia.org/wikipedia/commons/5/56/Hotel-room-renaissance-columbus-ohio.jpg">         
             </a>
              <a class="image"  href="gallery-restaurant.php">
                <span class="roll" >Restaurant</span>
                <img class="imgborder" alt="" src="http://www.limousine-hire-perth.com.au/C_RESTAURANT.jpg">         
             </a>
               <a class="image"  href="#">
                <span class="roll" >Fitness</span>
                <img class="imgborder" alt="" src="http://images.quikbook.com/400x300/hard-rock-hotel-chicago-chicago-gym-2514.jpg">         
             </a>
               <a class="image"  href="#">
                <span class="roll" >Spa</span>
                <img class="imgborder" alt="" src="http://www.flora-hotel.net/img/hotel-flora-spa-centre.jpg">         
             </a>
             <a class="image"  href="#">
                <span class="roll" >Sport</span>
                <img class="imgborder" alt="" src="http://thetenniscollege.net/wp-content/uploads/2013/10/tennis_court_type_grass_title.jpg">         
             </a>
             <a class="image"  href="#">
                <span class="roll" >Children facilities</span>
                <img class="imgborder" alt="" src="http://www.barcelo.com/BarceloHotels/en_GB/Images/children-playground-3-hotel-barcelo-lanzarote-resort21-3117.jpg">         
             </a>
    		</div>
<?php 

include 'includes/footer.inc.php';

 ?>