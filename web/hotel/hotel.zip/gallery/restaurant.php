<?php 

include '../includes/header.inc.php';

 ?>
    		<div id="main-content">
            <img src="http://www.limousine-hire-perth.com.au/C_RESTAURANT.jpg" alt="">
            <img src="http://www.limousine-hire-perth.com.au/C_RESTAURANT.jpg" alt="">
            <img src="http://www.limousine-hire-perth.com.au/C_RESTAURANT.jpg" alt="">
            <img src="http://www.limousine-hire-perth.com.au/C_RESTAURANT.jpg" alt="">
            <img src="http://www.limousine-hire-perth.com.au/C_RESTAURANT.jpg" alt="">
    		</div>
<?php 

include '../includes/footer.inc.php';

 ?>