	<footer id="web-footer">
		<section>
			<header><h3>HOTEL'S NAME</h3></header>
			<ul>				
				<li><a href="#">About us</a></li>
				<li><a href="#">Prices</a></li>
			</ul>
		</section>
		<section>
			<header><h3>GALLERY</h3></header>
			<ul>				
				<li><a href="#">Rooms</a></li>
				<li><a href="#">Restaurant</a></li>
				<li><a href="#">Sport</a></li>
				<li><a href="#">Children Facilities</a></li>
				<li><a href="#">Fitness</a></li>
				<li><a href="#">SPA</a></li>
			</ul>
		</section>
		<section>
			<header><h3>INFORMATION</h3></header>
			<ul>
				<li><a href="#">Book a room</a></li>
				<li><a href="#">Where are we?</a></li>
			</ul>
		</section>
		<section>
			<header><h3>WE ARE SOCIAL</h3></header>
			<ul>
				<li><a href="#">FACEBOOK</a></li>
				<li><a href="#">TWITTER</a></li>
				<li><a href="#">GOOGLE+</a></li>
			</ul>
		</section>
	</footer>
    	</div>
    </body>
</html>