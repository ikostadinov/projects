<?php 
$page = 'index.php';
include 'includes/header.inc.php';

 ?>
    		<div id="main-content">
    			<p>
    				Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quo, pariatur, deleniti ducimus animi excepturi asperiores odit laboriosam eaque accusantium totam facere dolorem ab nesciunt vel eos distinctio itaque corporis. Voluptates.
    			</p>
    			<a href="prices.php#reservation"><section>
    				<header><h2>BOOK A ROOM</h2></header>
    			</section></a>
    			<section>
    				<header><h2>SECTION2</h2></header>
    				<p>
    					Lorem ipsum dolor sit amet, consectetur adipisicing elit. Officiis, placeat, architecto esse aliquam molestias quas vel corporis sapiente hic reiciendis quidem magnam eius perferendis porro assumenda dolor impedit soluta alias.
    				</p>
    			</section>
    			<section>
    				<header><h2>SECTION3</h2></header>
    				<p>
    					Lorem ipsum dolor sit amet, consectetur adipisicing elit. Officiis, placeat, architecto esse aliquam molestias quas vel corporis sapiente hic reiciendis quidem magnam eius perferendis porro assumenda dolor impedit soluta alias.
    				</p>
    			</section>
    		</div>
<?php 

include 'includes/footer.inc.php';

 ?>